# Twitter ------------------------------------------------------------------------------------------

$TwitterConsumerKey           = ''
$TwitterConsumerSecret        = ''
$TwitterAccessToken           = ''
$TwitterAccessTokenSecret     = ''

# Facebook -----------------------------------------------------------------------------------------

$FBAccessToken                = ''
$FBDefaultPageId              = 0

# LinkedIn -----------------------------------------------------------------------------------------

$LinkedInApiKey               = ''
$LinkedInSecretKey            = ''
$LinkedInAccessToken          = ''
$LinkedInUserToken            = ''
$LinkedInUserSecret           = ''