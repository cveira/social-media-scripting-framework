$DefaultProfileName   = "master"
$ForcedSessionId      = ""
$DefaultSessionStore  = "" # "MyCampaign", "MyProject"
$DefaultDateFormat    = "yyyy/MM/dd hh:mm"
$LinkShorteners       = "t\.co|goo\.gl|bit\.ly|bitly\.com|j\.mp|ow\.ly|ow\.li|ht\.ly|htl\.li|dlvr\.it|tinyurl\.com|is\.gd|v\.gd|lnkd\.in|fb\.me|youtu\.be|aka\.ms|zite\.to|flip\.it|feedly\.com|pocket\.co"

$DefaultUserAgent     = "PowerShell"
$HashingMasterKey     = "nP9FdNZVU3R6jpz2vGbrDJS4c"