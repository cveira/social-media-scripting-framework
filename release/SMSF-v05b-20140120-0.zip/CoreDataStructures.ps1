. $InstallDir\CoreDataStructures_v01.ps1


$SCHEMA_DEFAULT       = $SCHEMA_VERSION_01


$SNPostMap = @{
  $SCHEMA_VERSION_01  = $SNPostTemplate_v01
}

$SNUserMap = @{
  $SCHEMA_VERSION_01  = $SNUserTemplate_v01
}

$DigitalProfileMap = @{
  $SCHEMA_VERSION_01  = $DigitalProfileTemplate_v01
}